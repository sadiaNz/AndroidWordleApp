package com.example.wordle

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat


class MainActivity : AppCompatActivity() {

    private val maxTries = 4
    private var tries = maxTries

    /**
     * Where the guessing stuff happens. Will later change tihs to a menu so i can have two
     * wordle versions if I can speed run this with enough monster energy drinks and
     * ecchi mangas
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var whatToGuess = FourLetterWord.getRandomFourLetterWord()
        val guessText = findViewById<TextView>(R.id.guess)
        val checkText = findViewById<TextView>(R.id.check)
        val answerText = findViewById<TextView>(R.id.answer)
        val guessAttemptIndicator =  findViewById<TextView>(R.id.remainingTries)
        val guessButton = findViewById<Button>(R.id.attemptedGuess)
        findViewById<EditText>(R.id.guessInput).setHint("Start Guessing..")
        guessAttemptIndicator.text = tries.toString()

        guessButton.setOnClickListener {
            // TODO: Change this text thing so it onl takes 4 letters and you can edit all 4 letters

            val attemptedGuessTxt = findViewById<EditText>(R.id.guessInput).text.toString().uppercase()
            val checkPlz = checkAnswer(whatToGuess, attemptedGuessTxt)
            guessText.text = StringBuilder(guessText.text).append("Guess: $attemptedGuessTxt\n").toString()
            checkText.text = colorManager(attemptedGuessTxt, checkPlz, "Check: ", checkText.text)
            val temp1 = StringBuilder()
            val oldAttempt = answerText.text.toString()

            for (i in 0 until 4)
            {
                temp1.append(if (checkPlz[i] == 'O') attemptedGuessTxt[i]
                    else if (attemptedGuessTxt[i] == '_') '_'
                    else if (oldAttempt.isNotEmpty()) oldAttempt[i]
                    else '_'
                )
            }
            answerText.text = temp1.toString()

            val buttonOpt = guessButton.text;

            if (buttonOpt == getString(R.string.guessSubmissionBtnText))
            {
                if (tries == 1)
                {
                    guessAttemptIndicator.text = "💀"
                    Toast.makeText(this, "No more tries left!!!!", Toast.LENGTH_SHORT).show()
                    guessButton.text = getString(R.string.RestartSubmissionBtnText)
                    answerText.text = whatToGuess
                }
                else
                {
                    if (checkPlz == "OOOO") {
                        guessAttemptIndicator.text = "..."
                        answerText.text = "Correct!"
                        answerText.text = buildString {
                            append("The answer is: ")
                            append(whatToGuess)
                        }
                        guessButton.text = getString(R.string.RestartSubmissionBtnText)
                    } else
                    {
                        tries = tries-1
                        guessAttemptIndicator.text = (tries).toString()
                    }
                }
            } else if (buttonOpt == getString(R.string.RestartSubmissionBtnText)) {
                tries = maxTries
                guessAttemptIndicator.text = tries.toString()
                answerText.text = ""
                checkText.text = ""
                whatToGuess = FourLetterWord.getRandomFourLetterWord() // Get a new word to guess
                guessText.text = "" // Clear the previous guessed text
                guessButton.text = getString(R.string.guessSubmissionBtnText)
            }
        }
    }

    private fun colorManager(guess: String, check: String, connector: String, prev: CharSequence = ""): SpannableStringBuilder
    {
        val spannableStringBuilder = SpannableStringBuilder()
        spannableStringBuilder.append(prev)
        spannableStringBuilder.append(connector)

        if (guess.isEmpty())
        {
            return spannableStringBuilder
        }
        var colorResId: Int = R.color.col02
        for (i in guess.indices)
        {
            val g = guess[i]
            when (check[i]) {
                'X' -> {
                    colorResId = R.color.col08
                }

                'O' -> {
                    colorResId = R.color.col0C
                }

                '+' -> {
                    colorResId = R.color.col09
                }
            }
            val color = ContextCompat.getColor(this, colorResId)
            val spannableString = SpannableString(g.toString())
            spannableString.setSpan(ForegroundColorSpan(color),
                0,
                1,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            spannableStringBuilder.append(spannableString)
        }
        spannableStringBuilder.append("\n")
        return spannableStringBuilder
    }

    private fun checkAnswer(answer: String, guess: String): String {
        val result = CharArray(answer.length) { '*' } // Initialize result array with '*'
        val charCountMap = answer.groupingBy { it }.eachCount().toMutableMap()

        // Check for characters that match in both position and value
        for (i in guess.indices) {
            if (answer[i] == guess[i]) {
                result[i] = 'O'
                charCountMap[guess[i]] = charCountMap.getOrDefault(guess[i], 0) - 1
            }
        }

        // Check for characters that are in the answer but in the wrong position
        for (i in guess.indices) {
            if (result[i] != '*') continue
            val currentChar = guess[i]
            if (charCountMap.getOrDefault(currentChar, 0) > 0) {
                result[i] = '+'
                charCountMap[currentChar] = charCountMap.getOrDefault(currentChar, 0) - 1
            } else {
                result[i] = 'X'
            }
        }
        return String(result)
    }
}